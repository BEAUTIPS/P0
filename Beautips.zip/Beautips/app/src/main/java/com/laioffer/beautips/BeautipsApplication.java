package com.laioffer.beautips;

import android.app.Application;

public class BeautipsApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
