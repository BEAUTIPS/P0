package com.laioffer.beautips.Fragments.HomePage;

import android.content.Context;

import java.net.MalformedURLException;
import java.net.URL;

public class ImageRepository {

}
